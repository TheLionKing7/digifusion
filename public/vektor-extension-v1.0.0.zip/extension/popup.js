// ── Config ────────────────────────────────────────────────────────────────────
const BACKEND = "https://vektor-xr-1.onrender.com";
const POLL_MS = 8000; // poll /api/latest every 8s while sweep is running

// ── DOM ───────────────────────────────────────────────────────────────────────
const dot            = document.getElementById("dot");
const statusText     = document.getElementById("status-text");
const lastSweepEl    = document.getElementById("last-sweep");
const nextSweepEl    = document.getElementById("next-sweep");
const refreshBtn     = document.getElementById("refresh-btn");
const loadingState   = document.getElementById("loading-state");
const loadingStep    = document.getElementById("loading-step");
const emptyState     = document.getElementById("empty-state");
const reportPanel    = document.getElementById("report-panel");
const copyPromptBtn  = document.getElementById("copy-prompt-btn");
const copyReportBtn  = document.getElementById("copy-report-btn");
const clearBtn       = document.getElementById("clear-btn");
const feedbackBar    = document.getElementById("feedback-bar");
const feedbackUpBtn  = document.getElementById("feedback-up-btn");
const feedbackDownBtn= document.getElementById("feedback-down-btn");
const feedbackNote   = document.getElementById("feedback-note");
const advancedToggle = document.getElementById("advanced-toggle");
const toggleArrow    = document.getElementById("toggle-arrow");
const advancedPanel  = document.getElementById("advanced-panel");
const manualQuery    = document.getElementById("manual-query");
const manualBtn      = document.getElementById("manual-btn");

let lastData       = null;
let pollTimer      = null;
let apiKey         = localStorage.getItem("vkt_api_key") || null;
let evtSource      = null;   // SSE connection — replaces polling when sweep is active
let isBusy         = false;
let sweepMode      = "auto";   // "auto" | "niche"
let selectedNiche  = null;     // niche id string e.g. "ai-automation"
let nicheLibrary   = [];       // populated from /api/niches on boot

// ── Helpers ───────────────────────────────────────────────────────────────────
function timeAgo(isoStr) {
  if (!isoStr) return "—";
  const diff = Math.floor((Date.now() - new Date(isoStr)) / 1000);
  if (diff < 60)  return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  return `${Math.floor(diff/86400)}d ago`;
}

function timeUntil(isoStr) {
  if (!isoStr) return "—";
  const diff = Math.floor((new Date(isoStr) - Date.now()) / 1000);
  if (diff <= 0)  return "soon";
  if (diff < 60)  return `${diff}s`;
  if (diff < 3600) return `${Math.floor(diff/60)}m`;
  return `${Math.floor(diff/3600)}h ${Math.floor((diff%3600)/60)}m`;
}

function setState(state) {
  isBusy = state === "busy";
  dot.className = `dot ${state === "busy" ? "busy" : state === "error" ? "error" : "idle"}`;
  refreshBtn.disabled = isBusy;
  manualBtn.disabled  = isBusy;
  statusText.textContent = state === "busy" ? "Sweeping..." : state === "error" ? "Error" : "Ready";
}

function setLoadingStep(msg) { loadingStep.textContent = msg; }

function showView(view) {
  loadingState.classList.toggle("visible", view === "loading");
  emptyState.classList.toggle("visible",   view === "empty" || view === "niche-ready");
  reportPanel.classList.toggle("visible",  view === "report");

  // When a niche is selected but not yet swept, show a targeted prompt
  const sub = document.querySelector(".empty-sub");
  if (sub) {
    if (view === "niche-ready" && selectedNiche) {
      const niche = nicheLibrary.find(n => n.id === selectedNiche);
      sub.innerHTML = `Niche selected: <span style="color:var(--amber)">${niche?.name || selectedNiche}</span><br><br>Hit <span style="color:var(--amber)">⟳ Sweep Now</span> to scan this niche for buyer intent.`;
    } else {
      sub.innerHTML = 'Hit <span style="color:var(--amber)">⟳ Sweep Now</span> to start.';
    }
  }
}

// ── Render report — v7 Framework B ──────────────────────────────────────────
function renderReport(d) {
  lastData = d;
  const ms  = d.marketSummary || {};
  const str = d.streams       || {};
  const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

  // Trigger badge + opp — always shows which sweep PRODUCED this result
  const tb = document.getElementById("trigger-badge");
  if (tb) {
    const nicheId   = (d.streams?.stage1?.letterGroup||"").replace("NICHE:","");
    const nicheName = nicheLibrary.find(n => n.id === nicheId)?.name || nicheId;
    const modeLabel = d.triggerMode === "niche"
      ? `🎯 ${nicheName || "Niche"}`
      : d.triggerMode === "auto"   ? "🔄 Auto"
      : "⚡ Manual";
    tb.className   = `section-badge ${d.triggerMode==="niche"?"badge-amber":d.triggerMode==="auto"?"mode-auto":"mode-manual"}`;
  }
  setEl("opp-badge", `Opp ${ms.opportunityScore || "?"}/10`);

  // Lite mode
  const lb = document.getElementById("lite-mode-badge");
  if (lb) lb.style.display = d.liteMode ? "block" : "none";

  // Memory bar
  const memBar = document.getElementById("memory-bar");
  const mem    = str.memory || {};
  if (memBar && mem.sweepCount) {
    memBar.style.display = "flex";
    setEl("mem-sweeps",  `${mem.sweepCount} sweeps`);
    setEl("mem-niches",  `${mem.knownNiches || 0} niches`);
    setEl("mem-lessons", `${mem.lessons || 0} lessons`);
  }

  // Niche + market summary
  setEl("niche-tag",    d.discoveredNiche || d.nicheDetected || "—");
  setEl("m-demand",     ms.demandLevel || "—");
  setEl("m-comp",       ms.competitionLevel || "—");
  setEl("m-money",      ms.monetizationPotential || "—");
  setEl("m-insight",    ms.insight || "");
  setEl("m-blue-ocean", ms.blueOceanScore ? `${ms.blueOceanScore}/10` : "—");

  // Intel layers readout
  const s1 = str.stage1 || {};
  setEl("intel-layers", `S1:[${s1.letterGroup||"?"}] ${s1.kindleSignals||0} · S2:${str.stage2?.confirmed||0} confirmed · S3:${str.stage3?.winners||0} winners`);

  // ── Trend Momentum ────────────────────────────────────────────────────────
  const trend = str.trendMomentum;
  const trendEl = document.getElementById("m-trend");
  if (trendEl) {
    trendEl.textContent = trend ? `${trend.label} (${trend.score}/10)` : "—";
  }

  // ── Price Intelligence ────────────────────────────────────────────────────
  const price = str.priceRange;
  const priceEl = document.getElementById("m-price");
  if (priceEl) {
    priceEl.textContent = price
      ? `$${price.min}–$${price.max} avg $${price.avg} · ${price.signal}`
      : "No price data";
  }

  // ── Amazon BSR Competition ─────────────────────────────────────────────────
  const bsr   = str.bsr;
  const bsrEl = document.getElementById("m-bsr");
  if (bsrEl) {
    if (bsr && bsr.reviews?.top !== null && bsr.reviews?.top !== undefined) {
      const priceStr = bsr.priceRange
        ? ` · Books priced $${bsr.priceRange.min}–$${bsr.priceRange.max}`
        : "";
      bsrEl.innerHTML =
        `<strong>${bsr.competition}</strong>${priceStr}<br>` +
        `Top book reviews: ${bsr.reviews.top?.toLocaleString() || "n/a"} · ` +
        `Avg reviews (top 5): ${bsr.reviews.avg?.toLocaleString() || "n/a"}`;
    } else {
      bsrEl.textContent = bsr ? bsr.competition : "BSR data unavailable";
    }
  }

  // Reader Pain Points
  const painBody = document.getElementById("pain-body");
  if (painBody) {
    painBody.innerHTML = "";
    const points = d.readerPainPoints || d.painPoints || [];
    setEl("pain-count", `${points.length} found`);
    points.forEach(p => {
      const iv  = p.intensity || 0;
      const cls = iv >= 8 ? "hi" : iv >= 5 ? "md" : "";
      const dom = p.dominantRegion || "GLOBAL";
      const dCls = dom === "NG" ? "region-ng" : dom === "US" ? "region-us" : "region-gl";
      const pain  = p.pain || p.painPoint || "";
      const angle = p.publishingAngle || p.commercialAngle || "";
      const ev    = (p.evidenceQueries || []).slice(0,2).join(", ");
      painBody.innerHTML += `
        <div class="pain-item">
          <div class="pain-top"><span class="pain-rank">#${p.rank}</span><span class="pain-text">${pain}</span></div>
          <div class="pain-meta">
            <span class="pain-tag ${cls}">Intensity ${iv}/10</span>
            <span class="pain-tag">${p.urgency||""}</span>
            <span class="pain-tag ${dCls}">${dom}</span>
          </div>
          ${ev ? `<div class="pain-angle" style="color:var(--muted);font-size:8px">📊 ${ev}</div>` : ""}
          <div class="pain-angle">💡 ${angle}</div>
        </div>`;
    });
  }

  // Unmet Desires
  const desBody = document.getElementById("desires-body");
  if (desBody) {
    desBody.innerHTML = "";
    (d.unmetDesires || []).forEach((des, i) => {
      desBody.innerHTML += `
        <div class="desire-item">
          <div class="desire-text">🎯 ${des.desire||""}</div>
          <div class="desire-meta"><span style="color:var(--amber)">${des.marketSize||""}</span>&nbsp;·&nbsp;${des.competitionGap||""}</div>
        </div>`;
    });
  }

  // 5-Point Structural Outline
  const outBody = document.getElementById("outline-body");
  if (outBody) {
    outBody.innerHTML = "";
    const ol = d.structuralOutline || {};
    if (ol.premise) outBody.innerHTML += `<div style="font-size:10px;color:var(--amber);padding:6px 0 4px;font-style:italic">"${ol.premise}"</div>`;
    (ol.chapters || []).forEach(ch => {
      const qs = (ch.keyQuestions||[]).map(q=>`<div style="font-size:9px;color:var(--muted);padding-left:8px">→ ${q}</div>`).join("");
      outBody.innerHTML += `
        <div class="chapter-item">
          <div class="chapter-num">CH ${ch.number}</div>
          <div class="chapter-title">${ch.title||""}</div>
          <div class="chapter-addresses">${ch.addresses||""}</div>
          ${qs}
        </div>`;
    });
  }

  // Title Options
  const titleBody = document.getElementById("title-body");
  if (titleBody) {
    titleBody.innerHTML = "";
    (d.titleOptions || []).forEach(t => {
      titleBody.innerHTML += `
        <div class="title-item">
          <div class="title-name">${t.title}</div>
          <div class="title-meta">
            <span class="section-badge badge-green" style="font-size:7px">${t.platform}</span>
            <span class="section-badge badge-amber" style="font-size:7px">${t.angle}</span>
            <span class="section-badge badge-blue"  style="font-size:7px">Score ${t.opportunityScore}/10</span>
          </div>
          <div class="title-why">${t.subtitle_rationale||t.whyItWorks||""}</div>
        </div>`;
    });
  }

  // AI Prompt
  setEl("prompt-text", d.aiPublishingPrompt || "");
  showView("report");
}

// ── Build text report — v7 ────────────────────────────────────────────────────
function buildTextReport(d) {
  const ms  = d.marketSummary || {};
  const str = d.streams       || {};
  let out   = `PROJECT VEKTOR v7 — MARKET INTELLIGENCE REPORT
${"═".repeat(60)}
`;
  out += `Niche: ${d.discoveredNiche||d.seed} | Regions: ${(d.regions||[]).join(",").toUpperCase()} | Mode: ${d.triggerMode}
`;
  out += `Generated: ${d.generatedAt} | Letter Group: ${str.stage1?.letterGroup||"?"}

`;

  out += `MARKET SUMMARY
${"─".repeat(50)}
`;
  out += `Opportunity: ${ms.opportunityScore}/10 | Blue Ocean: ${ms.blueOceanScore}/10 | Velocity: ${ms.velocitySignal||"—"}
`;
  out += `Demand: ${ms.demandLevel} | Competition: ${ms.competitionLevel} | Monetization: ${ms.monetizationPotential}
`;
  out += `Insight: ${ms.insight}

`;

  out += `READER PAIN POINTS
${"─".repeat(50)}
`;
  (d.readerPainPoints||d.painPoints||[]).forEach(p => {
    out += `
#${p.rank} ${p.pain||p.painPoint}
`;
    out += `   Intensity:${p.intensity}/10 | ${p.urgency} | ${p.dominantRegion||"GLOBAL"}
`;
    out += `   Angle: ${p.publishingAngle||p.commercialAngle}
`;
    if ((p.evidenceQueries||[]).length) out += `   Evidence: ${p.evidenceQueries.slice(0,2).join(", ")}
`;
  });

  out += `
UNMET DESIRES
${"─".repeat(50)}
`;
  (d.unmetDesires||[]).forEach((des,i) => {
    out += `
${i+1}. ${des.desire}
   ${des.marketSize} market | ${des.competitionGap}
`;
  });

  out += `
5-POINT STRUCTURAL OUTLINE
${"─".repeat(50)}
`;
  if (d.structuralOutline) {
    out += `Premise: ${d.structuralOutline.premise}
`;
    (d.structuralOutline.chapters||[]).forEach(ch => {
      out += `
CH${ch.number}: ${ch.title}
  ${ch.addresses}
`;
      (ch.keyQuestions||[]).forEach(q => out += `  → ${q}
`);
    });
  }

  out += `
TITLE OPTIONS
${"─".repeat(50)}
`;
  (d.titleOptions||[]).forEach((t,i) => {
    out += `
${i+1}. ${t.title}
   ${t.platform} | ${t.angle} | Score:${t.opportunityScore}/10
   ${t.subtitle_rationale||t.whyItWorks}
`;
  });

  out += `
AI PUBLISHING PROMPT
${"─".repeat(50)}
${d.aiPublishingPrompt}`;
  return out;
}

// ── Fetch latest report ───────────────────────────────────────────────────────
async function fetchLatest(showLoading = true) {
  try {
    if (showLoading) showView("loading");
    const res  = await fetch(`${BACKEND}/api/latest`, { headers: getAuthHeaders(), signal: AbortSignal.timeout(15_000) });
    const data = await res.json();

    // Update sweep times
    lastSweepEl.textContent = timeAgo(data.lastSweepTime);
    nextSweepEl.textContent = `in ${timeUntil(data.nextSweepTime)}`;

    if (data.sweepStatus === "running") {
      setState("busy");
      // Rotate loading messages to show pipeline stages
      const isNicheMode = sweepMode === "niche" && selectedNiche;
      const nicheName   = isNicheMode ? (nicheLibrary.find(n=>n.id===selectedNiche)?.name||selectedNiche) : null;
      const stages = isNicheMode ? [
        `S1: Kindle sweep → "${nicheName}" niche space...`,
        `S2: Google cross-validation of ${nicheName} signals...`,
        "S3: Opportunity scoring within niche...",
        "S4: Framework B sub-niche analysis...",
        "🧠 Identifying the golden sub-niche...",
      ] : [
        "S1: Amazon Kindle alphabet soup → capturing buyer intent...",
        "S2: Google Suggest cross-validation...",
        "S3: Opportunity scoring (Framework A)...",
        "S4: Master analysis (Framework B)...",
        "🧠 Learning from signals...",
      ];
      const step = stages[Math.floor(Date.now() / 4000) % stages.length];
      setLoadingStep(step);
      showView("loading");
      schedulePoll();
    } else {
      setState("idle");
      stopPoll();
      if (data.hasReport && data.report) {
        // Attach historyId from history so feedback can reference the record
        const report = data.report;
        if (!report.historyId && data.historyCount > 0) {
          try {
            const hRes  = await fetch(`${BACKEND}/api/history`, { headers: getAuthHeaders() });
            const hData = await hRes.json();
            if (hData.reports?.[0]) report.historyId = hData.reports[0].historyId;
          } catch(_) {}
        }
        renderReport(report);
        resetFeedbackBar();
      } else {
        // Show last error in empty state subtitle if available
        const sub = document.querySelector(".empty-sub");
        if (sub && data.lastError) {
          sub.innerHTML = `Last sweep error:<br><span style="color:var(--red);font-size:9px">${data.lastError}</span><br><br>Hit <span style="color:var(--amber)">⟳ Sweep Now</span> to retry.`;
        }
        showView("empty");
      }
    }
  } catch (err) {
    setState("error");
    showView("empty");
    console.error("fetchLatest error:", err.message);
  }
}

// ── SSE — real-time pipeline events (replaces polling) ───────────────────────
function connectSSE() {
  if (evtSource) return; // already connected
  try {
    evtSource = new EventSource(`${BACKEND}/api/stream`);

    evtSource.onmessage = async (e) => {
      try {
        const evt = JSON.parse(e.data);
        await handleSSEEvent(evt);
      } catch(_) {}
    };

    evtSource.onerror = () => {
      // SSE dropped — fall back to polling so UX never stalls
      evtSource?.close();
      evtSource = null;
      schedulePoll();
    };
  } catch(_) {
    evtSource = null;
    schedulePoll(); // graceful fallback
  }
}

async function handleSSEEvent(evt) {
  if (evt.type === "log") {
    // Update loading message with real pipeline stage from server log
    if (evt.sweepStatus === "running") {
      const clean = evt.line.replace(/\[\d{4}-\d{2}-\d{2}T[\d:.Z]+\]\s*/, "");
      setLoadingStep(clean);
      setState("busy");
      showView("loading");
    }
  } else if (evt.type === "complete") {
    // Sweep finished — render report immediately, no extra fetch needed
    setState("idle");
    stopPoll();
    const report = evt.report;
    if (report) {
      if (evt.lastSweepTime) lastSweepEl.textContent = timeAgo(evt.lastSweepTime);
      if (evt.nextSweepTime) nextSweepEl.textContent = `in ${timeUntil(evt.nextSweepTime)}`;
      renderReport(report);
      resetFeedbackBar();
    }
  } else if (evt.type === "error") {
    setState("idle");
    stopPoll();
    showView("empty");
  } else if (evt.type === "status") {
    // Initial state snapshot on connect
    if (evt.lastSweepTime) lastSweepEl.textContent = timeAgo(evt.lastSweepTime);
    if (evt.nextSweepTime) nextSweepEl.textContent = `in ${timeUntil(evt.nextSweepTime)}`;
    if (evt.sweepStatus === "running") {
      setState("busy");
      showView("loading");
    }
  }
}

function disconnectSSE() {
  if (evtSource) { evtSource.close(); evtSource = null; }
}

// ── Polling fallback (used when SSE unavailable) ──────────────────────────────
function schedulePoll() {
  if (pollTimer) return;
  pollTimer = setInterval(() => fetchLatest(false), POLL_MS);
}
function stopPoll() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

// ── Trigger sweep now ─────────────────────────────────────────────────────────
async function triggerSweep() {
  if (isBusy) return;

  // Validate niche selection in niche mode
  if (sweepMode === "niche" && !selectedNiche) {
    const grid = document.getElementById("niche-grid");
    if (grid) { grid.style.outline = "1px solid var(--red)"; setTimeout(() => grid.style.outline="", 1500); }
    return;
  }

  setState("busy");
  showView("loading");

  const isNiche = sweepMode === "niche" && selectedNiche;
  const nicheName = isNiche ? (nicheLibrary.find(n => n.id === selectedNiche)?.name || selectedNiche) : null;

  setLoadingStep(isNiche
    ? `🎯 Niche sweep: "${nicheName}"...`
    : "🔄 Autonomous sweep — alphabet soup..."
  );

  try {
    const body = isNiche ? { nicheId: selectedNiche } : {};
    await fetch(`${BACKEND}/api/sweep`, {
      method: "POST",
      headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10_000),
    });
    setLoadingStep(isNiche
      ? `S1: Kindle sweep within "${nicheName}" niche space...`
      : "S1: Amazon Kindle zero-seed alphabet soup..."
    );
    schedulePoll();
  } catch (err) {
    setState("error");
    showView(lastData ? "report" : "empty");
  }
}

// ── Manual query pipeline ─────────────────────────────────────────────────────
async function runManual() {
  const query   = manualQuery.value.trim();
  const regions = [...document.querySelectorAll(".region-chip.active")].map(c => c.dataset.region);

  if (!query) {
    manualQuery.style.borderColor = "var(--red)";
    setTimeout(() => { manualQuery.style.borderColor = ""; }, 1500);
    return;
  }

  setState("busy");
  showView("loading");
  setLoadingStep(`Manual sweep: "${query}" | S1: Kindle probe...`);

  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), 90_000);

  try {
    const res = await fetch(`${BACKEND}/api/manual`, { headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, regions }),
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }

    const data = await res.json();
    setState("idle");
    // Show stream summary in loading step before rendering
    const s = data.streams || {};
    setLoadingStep(`✓ ${(data.discoveredNiche||data.seed||"").slice(0,40)} | Score:${s.winner?.score||"?"}`);
    setTimeout(() => renderReport(data), 300);

  } catch (err) {
    clearTimeout(timeout);
    setState("error");
    showView(lastData ? "report" : "empty");
    console.error("Manual error:", err.message);
  }
}

// ── Copy helpers ──────────────────────────────────────────────────────────────
async function copyText(text, btn, label) {
  try {
    await navigator.clipboard.writeText(text);
    btn.textContent = "Copied ✓";
    setTimeout(() => { btn.textContent = label; }, 2000);
  } catch (_) {
    btn.textContent = "Failed";
    setTimeout(() => { btn.textContent = label; }, 2000);
  }
}

// ── Region chips ──────────────────────────────────────────────────────────────
document.querySelectorAll(".region-chip").forEach(chip => {
  chip.addEventListener("click", () => {
    const active = document.querySelectorAll(".region-chip.active");
    if (chip.classList.contains("active")) {
      if (active.length > 1) chip.classList.remove("active");
    } else {
      if (active.length < 3) chip.classList.add("active");
    }
  });
});

// ── Auto-capture Google query into manual input ───────────────────────────────
async function autoCapture() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    const url = new URL(tab.url);
    if (url.hostname.includes("google.com") && url.searchParams.has("q")) {
      manualQuery.value = url.searchParams.get("q");
    }
  } catch (_) {}
}

// ── Event listeners ───────────────────────────────────────────────────────────
refreshBtn.addEventListener("click", triggerSweep);
manualBtn.addEventListener("click", runManual);
manualQuery.addEventListener("keydown", e => { if (e.key === "Enter" && !isBusy) runManual(); });

copyPromptBtn.addEventListener("click", () => {
  if (lastData?.aiPublishingPrompt) copyText(lastData.aiPublishingPrompt, copyPromptBtn, "Copy Prompt");
});
copyReportBtn.addEventListener("click", () => {
  if (lastData) copyText(buildTextReport(lastData), copyReportBtn, "Copy Report");
});
clearBtn.addEventListener("click", () => {
  lastData = null;
  showView("empty");
  resetFeedbackBar();
});

// ── Feedback bar ──────────────────────────────────────────────────────────────
function resetFeedbackBar() {
  if (!feedbackUpBtn || !feedbackDownBtn) return;
  feedbackUpBtn.classList.remove("active-up");
  feedbackDownBtn.classList.remove("active-down");
  if (feedbackNote) { feedbackNote.textContent = ""; feedbackNote.classList.remove("visible"); }
}

async function sendFeedback(rating) {
  if (!lastData?.historyId) {
    // historyId may be in the report history — use generatedAt as fallback key
    showFeedbackNote("⚠ Rating noted locally — no historyId to sync with server.");
    return;
  }
  try {
    feedbackUpBtn.disabled   = true;
    feedbackDownBtn.disabled = true;
    const res  = await fetch(`${BACKEND}/api/feedback`, {
      method:  "POST",
      headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
      body:    JSON.stringify({ historyId: lastData.historyId, rating }),
    });
    const data = await res.json();
    if (data.ok) {
      const emoji = rating === "up" ? "👍" : "👎";
      const msg   = rating === "up"
        ? `${emoji} Reinforced! This pattern will be prioritised in future sweeps.`
        : `${emoji} Noted. This signal is blocked — the agent will avoid it going forward.`;
      showFeedbackNote(msg);
      if (rating === "up") feedbackUpBtn.classList.add("active-up");
      else                 feedbackDownBtn.classList.add("active-down");
    } else {
      showFeedbackNote("⚠ Could not save feedback: " + (data.error || "unknown error"));
    }
  } catch(e) {
    showFeedbackNote("⚠ Network error — feedback not saved.");
  } finally {
    feedbackUpBtn.disabled   = false;
    feedbackDownBtn.disabled = false;
  }
}

function showFeedbackNote(msg) {
  if (!feedbackNote) return;
  feedbackNote.textContent = msg;
  feedbackNote.classList.add("visible");
}

feedbackUpBtn.addEventListener("click",   () => sendFeedback("up"));
feedbackDownBtn.addEventListener("click", () => sendFeedback("down"));

// Advanced toggle
advancedToggle.addEventListener("click", () => {
  const open = advancedPanel.classList.toggle("visible");
  toggleArrow.classList.toggle("open", open);
});

// ── Report History ────────────────────────────────────────────────────────────
async function fetchHistory() {
  try {
    const res  = await fetch(`${BACKEND}/api/history`, { headers: getAuthHeaders(), signal: AbortSignal.timeout(8_000) });
    const data = await res.json();
    renderHistoryDropdown(data.reports || []);
  } catch (_) {}
}

function renderHistoryDropdown(reports) {
  const sel = document.getElementById("history-select");
  if (!sel) return;

  // Clear existing options except placeholder
  while (sel.options.length > 1) sel.remove(1);

  reports.forEach((r, i) => {
    const opt   = document.createElement("option");
    opt.value   = r.historyId;
    const time  = r.sweepTime ? new Date(r.sweepTime).toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" }) : "—";
    const date  = r.sweepTime ? new Date(r.sweepTime).toLocaleDateString([], { month:"short", day:"numeric" }) : "";
    opt.text    = `${date} ${time} — ${(r.nicheDetected || r.seed || "").slice(0, 30)}`;
    sel.appendChild(opt);
  });
}

async function loadHistoryReport(historyId) {
  if (!historyId) return;
  try {
    showView("loading");
    setLoadingStep("Loading report from history...");
    const res  = await fetch(`${BACKEND}/api/history/${historyId}`, { headers: getAuthHeaders(), signal: AbortSignal.timeout(10_000) });
    const data = await res.json();
    if (data && data.seed) {
      renderReport(data);
    } else {
      showView("empty");
    }
  } catch (_) {
    showView(lastData ? "report" : "empty");
  }
}

// History select listener
document.getElementById("history-select")?.addEventListener("change", e => {
  const val = e.target.value;
  if (val) loadHistoryReport(val);
});

// ── Niche selector ────────────────────────────────────────────────────────────
function setSweepMode(mode) {
  sweepMode = mode;
  document.getElementById("mode-auto-btn").classList.toggle("active",  mode === "auto");
  document.getElementById("mode-niche-btn").classList.toggle("active", mode === "niche");
  const panel = document.getElementById("niche-panel");
  if (panel) panel.classList.toggle("visible", mode === "niche");
  // If switching to niche mode and grid is empty, retry fetch
  if (mode === "niche" && nicheLibrary.length === 0) {
    fetchNiches();
  }
}

function renderNicheGrid(niches) {
  const grid = document.getElementById("niche-grid");
  if (!grid) return;
  grid.innerHTML = "";
  niches.forEach(n => {
    const chip  = document.createElement("button");
    chip.className   = "niche-chip";
    chip.dataset.id  = n.id;
    const demandShort = n.demand === "Very High" ? "🔥 VH" : n.demand === "High" ? "⬆ Hi" : n.demand === "Growing" ? "📈 ↑" : n.demand;
    chip.innerHTML = `<span>${n.label}</span><span class="niche-demand">${demandShort}</span>`;
    chip.addEventListener("click", () => {
      document.querySelectorAll(".niche-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      selectedNiche = n.id;
      // Clear old report immediately — it belongs to a different niche/sweep.
      // User must hit Sweep Now to get results for this niche.
      if (lastData) {
        lastData = null;
        showView("niche-ready");
      }
    });
    grid.appendChild(chip);
  });
}



async function fetchNiches() {
  const grid = document.getElementById("niche-grid");
  if (grid) grid.innerHTML = '<div style="padding:12px;color:var(--muted);font-size:11px;">Loading niches...</div>';
  try {
    const res  = await fetch(`${BACKEND}/api/niches`, { headers: getAuthHeaders(), signal: AbortSignal.timeout(10_000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    nicheLibrary = data.niches || [];
    if (nicheLibrary.length === 0) throw new Error("Empty niche list");
    renderNicheGrid(nicheLibrary);
  } catch (err) {
    console.error("fetchNiches error:", err.message);
    // Show retry button so user is not stuck with empty grid
    if (grid) grid.innerHTML = `<div style="padding:12px;color:var(--muted);font-size:11px;">
      Could not load niches. <button onclick="fetchNiches()" style="color:var(--amber);background:none;border:none;cursor:pointer;font-size:11px;">Retry</button>
    </div>`;
  }
}

// ── AUTH ─────────────────────────────────────────────────────────────────────
function getAuthHeaders() {
  return apiKey ? { "x-api-key": apiKey } : {};
}

function showAuthScreen(visible) {
  const authEl  = document.getElementById("auth-screen");
  const mainEls = [
    document.getElementById("sweep-bar"),
    document.getElementById("history-bar"),
    document.querySelector(".memory-bar"),
    document.getElementById("usage-bar-wrap"),
    document.querySelector(".niche-bar"),
    document.getElementById("report-panel"),
    document.getElementById("advanced-toggle"),
  ];
  if (authEl) authEl.classList.toggle("visible", visible);
  mainEls.forEach(el => { if (el) el.style.display = visible ? "none" : ""; });
}

async function submitApiKey() {
  const input = document.getElementById("auth-key-input");
  const errEl = document.getElementById("auth-error");
  const key   = (input?.value || "").trim();
  if (!key.startsWith("vkt_")) {
    errEl.textContent = "Key must start with vkt_ — check your key.";
    errEl.classList.add("visible");
    return;
  }
  // Validate key against server
  try {
    const res  = await fetch(`${BACKEND}/api/user`, { headers: { "x-api-key": key } });
    if (!res.ok) {
      errEl.textContent = "Invalid API key. Try again or register at the link below.";
      errEl.classList.add("visible");
      return;
    }
    const user = await res.json();
    apiKey = key;
    localStorage.setItem("vkt_api_key", key);
    errEl.classList.remove("visible");
    showAuthScreen(false);
    updateUsageBar(user);
    await bootMain();
  } catch(_) {
    errEl.textContent = "Could not connect to server. Check your connection.";
    errEl.classList.add("visible");
  }
}

function updateUsageBar(user) {
  const wrap  = document.getElementById("usage-bar-wrap");
  const label = document.getElementById("usage-label-text");
  const count = document.getElementById("usage-label-count");
  const fill  = document.getElementById("usage-fill");
  if (!wrap) return;

  const limit = user.sweepsLimit;
  const used  = user.sweepsUsed || 0;

  if (limit === -1) {
    // Unlimited
    if (label) label.textContent = `${user.plan} — Unlimited sweeps`;
    if (count) count.textContent = `${used} used`;
    if (fill)  fill.style.width  = "20%";
  } else {
    const pct = Math.min((used / limit) * 100, 100);
    if (label) label.textContent = `${user.plan} plan — ${limit - used} sweeps remaining`;
    if (count) count.textContent = `${used}/${limit}`;
    if (fill)  fill.style.width  = `${pct}%`;
    if (fill)  fill.style.background = pct > 80 ? "var(--red)" : "var(--amber)";
  }
  wrap.style.display = "block";
}

async function fetchUserInfo() {
  if (!apiKey) return;
  try {
    const res  = await fetch(`${BACKEND}/api/user`, { headers: getAuthHeaders() });
    if (res.status === 401) { apiKey = null; localStorage.removeItem("vkt_api_key"); showAuthScreen(true); return; }
    if (!res.ok) return;
    const user = await res.json();
    updateUsageBar(user);
  } catch(_) {}
}

async function bootMain() {
  await fetchNiches();
  await fetchLatest(true);
  await fetchHistory();
  connectSSE();
  setInterval(() => { if (!isBusy) { fetchLatest(false); fetchHistory(); fetchUserInfo(); } }, 60_000);
}

// ── Boot ──────────────────────────────────────────────────────────────────────
(async () => {
  // ── Mode toggle buttons — wired here so DOM is guaranteed ready ──────────
  document.getElementById("mode-auto-btn").addEventListener("click",  () => setSweepMode("auto"));
  document.getElementById("mode-niche-btn").addEventListener("click", () => setSweepMode("niche"));

  // ── Auth screen button ────────────────────────────────────────────────────
  const authBtn  = document.getElementById("auth-submit-btn");
  const authLink = document.getElementById("auth-register-link");
  if (authBtn)  authBtn.addEventListener("click", submitApiKey);
  if (authLink) authLink.addEventListener("click", () => {
    chrome.tabs.create({ url: `${BACKEND}/register` });
  });
  // Allow Enter key in API key input
  const authInput = document.getElementById("auth-key-input");
  if (authInput) authInput.addEventListener("keydown", e => { if (e.key === "Enter") submitApiKey(); });

  // ── Check stored API key ──────────────────────────────────────────────────
  if (!apiKey) {
    showAuthScreen(true);
    return; // don't boot main until user authenticates
  }

  // Validate stored key is still valid
  try {
    const res = await fetch(`${BACKEND}/api/user`, { headers: getAuthHeaders() });
    if (res.status === 401) {
      apiKey = null;
      localStorage.removeItem("vkt_api_key");
      showAuthScreen(true);
      return;
    }
    if (res.ok) {
      const user = await res.json();
      updateUsageBar(user);
    }
  } catch(_) {} // network error — proceed anyway with stored key

  showAuthScreen(false);
  await bootMain();
})();